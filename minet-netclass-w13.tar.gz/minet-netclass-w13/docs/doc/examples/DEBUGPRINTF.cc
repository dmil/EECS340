// The following message will be displayed if MINET_DEBUGLEVEL is at least 3
DEBUGPRINTF(3, "Warning on line %d in file %s: Can't connect to IP module.\n", __LINE__, __FILE__);
/**
 * @example DEBUGPRINTF.cc
 * This is an example of how to use the DEBUGPRINTF() function.
 */
